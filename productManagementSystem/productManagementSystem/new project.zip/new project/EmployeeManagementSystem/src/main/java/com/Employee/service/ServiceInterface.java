package com.Employee.service;

import com.Employee.modal.Employee;

import java.util.List;

public interface ServiceInterface {


    public List<Employee> saveAllEmployee();

}
