package com.Employee.Exception_Handling;

public class EmployeesNotFoundException extends RuntimeException {
    public EmployeesNotFoundException(String s) {
    }
}
