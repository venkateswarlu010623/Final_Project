package com.Employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystemApplication
{

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemApplication.class, args);
	}

}












//github token = " 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 "