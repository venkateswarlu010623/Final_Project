package com.product.modal;


import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@Entity
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int sid;
    String name;

    @OneToOne(cascade = CascadeType.ALL,mappedBy = "student")
    @JoinColumn(referencedColumnName = "sid")
    Address address;
}