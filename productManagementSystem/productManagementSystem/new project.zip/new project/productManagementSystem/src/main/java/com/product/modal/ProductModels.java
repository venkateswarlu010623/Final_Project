package com.product.modal;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.Pattern;

@Data
@NoArgsConstructor
@Entity
public class ProductModels {

    @Id
    @GeneratedValue(generator = "modalId")
    @GenericGenerator(name = "modalId", strategy = "org.hibernate.id.UUIDGenerator")
    String modalId;

    String color;
    String length;
    String width;

    @ManyToOne
    @JoinColumn(name = "productId")
    Product product;
}
