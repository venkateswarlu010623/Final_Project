package com.product.modal;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Data
@NoArgsConstructor
@Entity
public class Product {

    @Id
    @SequenceGenerator(name = "productId", initialValue = 200)
    @GeneratedValue(strategy = GenerationType.IDENTITY ,generator = "productId")
    private int productId;

    private String productName;
    private int productPrice;
    private String productBrand;

    @OneToMany(cascade ={CascadeType.ALL},mappedBy = "product")
    private List<ProductModels> productModelsList;
//
//    public Product(int productId, String productName, int productPrice, String productBrand) {
//        this.productId = productId;
//        this.productName = productName;
//        this.productPrice = productPrice;
//        this.productBrand = productBrand;
//    }
//
//    public int getProductId() {
//        return productId;
//    }
//
//    public void setProductId(int productId) {
//        this.productId = productId;
//    }
//
//    public String getProductName() {
//        return productName;
//    }
//
//    public void setProductName(String productName) {
//        this.productName = productName;
//    }
//
//    public int getProductPrice() {
//        return productPrice;
//    }
//
//    public void setProductPrice(int productPrice) {
//        this.productPrice = productPrice;
//    }
//
//    public String getProductBrand() {
//        return productBrand;
//    }
//
//    public void setProductBrand(String productBrand) {
//        this.productBrand = productBrand;
//    }
//
//    @Override
//    public String toString() {
//        return "Product{" +
//                "productId=" + productId +
//                ", productName='" + productName + '\'' +
//                ", productPrice=" + productPrice +
//                ", productBrand='" + productBrand + '\'' +
//                '}';
//    }
}
