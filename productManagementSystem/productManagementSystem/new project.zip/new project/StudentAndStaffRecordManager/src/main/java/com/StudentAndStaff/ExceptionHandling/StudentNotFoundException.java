package com.StudentAndStaff.ExceptionHandling;

public class StudentNotFoundException extends RuntimeException {
}
