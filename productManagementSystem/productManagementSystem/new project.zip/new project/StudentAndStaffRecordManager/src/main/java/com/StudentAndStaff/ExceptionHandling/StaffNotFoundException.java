package com.StudentAndStaff.ExceptionHandling;

public class StaffNotFoundException extends RuntimeException{
    public StaffNotFoundException(String s) {
    }
}
