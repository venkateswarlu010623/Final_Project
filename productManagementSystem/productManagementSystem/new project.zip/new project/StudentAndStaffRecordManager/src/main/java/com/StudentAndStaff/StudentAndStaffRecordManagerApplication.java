package com.StudentAndStaff;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentAndStaffRecordManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentAndStaffRecordManagerApplication.class, args);
	}

}
